#include <iostream>
#include <string>
#include <conio.h>
#include <windows.h>
#include <fstream>
#include "Notepad.h"

using namespace std;


void main()
{
	cout << " _______                   _       ______       _   _   _                    " << endl;
	cout << "|__   __|                 | |     |  ____|     | | (_) | |                   " << endl;
	cout << "   | |      ___   __  __  | |_    | |__      __| |  _  | |_   ___    _ __   " << endl;
	cout << "   | |     / _ \\  \\ \\/ /  | __|   |  __|    / _` | | | | __| / _ \\  | '__|  " << endl;
	cout << "   | |    |  __/   >  <   | |_    | |____  | (_| | | | | |_ | (_) | | |     " << endl;
	cout << "   |_|    \\___|   /_/\\_\\  \\__|    |______|  \\__,_| |_| \\__|  \\___/  |_|     " << endl;

	cout << "-------------------------------------------------------------------------------" << char(191) << endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
	cout << "Menu";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	cout << ":                                                                          |" << endl;
	cout << "-------------------------------------------------------------------------------|" << endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
	cout << "F2";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	cout << "- Save File";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
	cout << "	F3";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	cout << " -Read From File   ";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
	cout << "Esc";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	cout << "- Quit                                 | " << endl;
	cout << "                                                                               |" << endl;
	cout << "-------------------------------------------------------------------------------" << char(180) << endl;
	cout << "                                                                               |" << endl;
	cout << "                                                                               |" << endl;
	cout << "                                                                               |" << endl;
	cout << "                                                                               |" << endl;
	cout << "                                                                               |" << endl;
	cout << "                                                                               |" << endl;
	cout << "                                                                               |" << endl;
	cout << "                                                                               |" << endl;
	cout << "                                                                               |" << endl;
	cout << "                                                                               |" << endl;
	cout << "-------------------------------------------------------------------------------" << char(217) << endl;

	Node notepad; //class full of functions
	notepad.Run();

	//keeps console clean
	while (1);
}
