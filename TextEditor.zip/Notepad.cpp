#include "Notepad.h"


void gotoxy(int column, int line)
{
	COORD coord;
	coord.X = column;
	coord.Y = line;
	SetConsoleCursorPosition(
		GetStdHandle(STD_OUTPUT_HANDLE),
		coord
	);
}

void Node::Run()
{
	Node* start = nullptr; //initialize start ptr
	Node* end = nullptr; //initialize end ptr
	Node* curr = nullptr; //initialize current ptr
	Node* rows[10]; //rows to go to next line

	char c; //char places in nodes

	std::string filetrail_save; //file route to save to
	std::string filetrail_read; //file route to read from

	int x, y; //x and y used for cursor location

	int rowNumber = 0; // rowNumber used for positioning 
	int numberofnodes = 0; //used to count number of nodes in row above or below

	//used to get special key inputs
	/*while (1)
	{
		c = _getch();
		cout << (int)c << endl;
	}*/

	x = 0;
	y = 12; //intialize x ,y

	//set rows to null
	for (int i = 0; i < 10; i++)
		rows[i] = nullptr;

	while (1)
	{
		c = _getch();

		//if Esc end program
		if (c == 27)
			break;

		//file save/read keys
		else if ((int)c == 0)
		{
			c = _getch();
			if ((int)c == 60) //F2-save file
			{
				gotoxy(0, 22);
				cout << endl;
				cout << "What is the file trail you want to save to?" << endl;
				cout << "Example: c:\\temp\\output.txt" << endl;
				std::getline(std::cin, filetrail_save);

				ofstream outfile(filetrail_save);
				gotoxy(x, y);
				for (int i = 0; i < 10; i++)
				{
					if (rows[i] != nullptr)
					{
						Node* T;
						T = rows[i];
						while (T != nullptr)
						{
							outfile << T->letter;
							T = T->next;
						}
						outfile << endl;
					}
				}
				outfile.close();
			}

			else if ((int)c == 61) //F3-read file
			{
				gotoxy(0, 22);
				cout << endl;
				cout << "What is the file trail you read from?" << endl;
				cout << "Example: c:\\temp\\output.txt" << endl;
				std::getline(std::cin, filetrail_read);

				ifstream infile(filetrail_read);

				if (!infile)
				{
					cout << "Error. File does not exist.";
					exit(-1);
				}

				while (infile >> letter)
				{
					for (int i = 0; i < 10; i++)
					{
						if (rows[i] != nullptr)
						{
							Node* T;
							T = rows[i];
							while (T != nullptr)
							{
								infile >> T->letter;
								T = T->next;
							}
						}
						infile.close();
					}
				}

				for (int i = 0; i < 10; i++)
				{
					if (rows[i] != nullptr)
					{
						Node* T;
						T = rows[i];
						while (T != nullptr)
						{
							cout << T->letter;
							T = T->next;
						}
						cout << endl;
					}
				}
				gotoxy(x, y);


			}
		}

		//backpace
		else if (c == 8)
		{
			//if (end->prev == rows[rowNumber]) 
			//{
			//	delete (start);
			//	start = nullptr;
			//	end = start;
			//	x--;
			//}
			/*if (end->prev != nullptr)*/

			if (end->prev == rows[rowNumber])
			{
				end = end->prev;
				if (end->next != nullptr)
				{
					// Two letters left
					delete (end->next);
					end->next = nullptr;
				}
				else
				{
					// One letter left
					delete(start);
					rows[rowNumber] = nullptr;
					start = nullptr;
				}
			}
			else
			{
				end = end->prev;
				delete (end->next);
				end->next = nullptr;
			}
			x--;
		}

		//directional keys
		else if ((int)c == -32)
		{
			c = _getch();
			if ((int)c == 75) //left
			{
				if (curr->prev != nullptr)
				{
					curr = curr->prev;
					x--;
				}
			}

			else if ((int)c == 77) //right
			{
				if (curr->next != nullptr)
				{
					curr = curr->next;
					x++;
				}
			}

			else if ((int)c == 72) //up 
			{
				if (rows[rowNumber - 1] != nullptr)
				{
					rowNumber--;
					y--;
					end = curr = start = rows[rowNumber];
					while (end != nullptr)
					{
						end = end->next;
					}
					end = curr = start;
					x = 0;
					gotoxy(x, y);
				}
			}

			else if ((int)c == 80) //down 
			{
				if (rows[rowNumber + 1] != nullptr)
				{
					rowNumber++;
					y++;
					end = curr = start = rows[rowNumber];
					while (end != nullptr)
					{
						end = end->next;
					}
					end = curr = start;
					x = 0;
					gotoxy(x, y);
				}
			}
		}

		//next line
		else if (c == 13)
		{
			rowNumber++;
			y++;
			x = 0;
			gotoxy(x, y);
			start = end = curr = rows[rowNumber];
		}

		else
		{
			//regular character
			if (start == nullptr)
			{
				Node* p = new Node(c);
				start = p;
				end = p;
				curr = p;
				x++;
				rows[rowNumber] = start;
				start->prev = rows[rowNumber];
			}

			else
			{
				//insert at the end
				if (curr == end)
				{
					Node* p = new Node(c);
					end->next = p;
					p->prev = end;
					end = p;
					curr = end;
					x++;
				}

				//insert in middle
				else if (curr->next != nullptr && curr->prev != nullptr)
				{
					Node* p = new Node(c);
					p->next = curr->next;
					curr->next->prev = p;
					p->prev = curr;
					curr->next = p;
					curr = p;
					x++;
				}

				//insert at beggining 
				else if (curr->next == start)
				{
					Node* p = new Node(c);

					//link new node to start
					p->next = start;

					//move start to new node
					start = p;
					x++;
				}
			}
		}

		system("cls");

		cout << " _______                   _       ______       _   _   _                    " << endl;
		cout << "|__   __|                 | |     |  ____|     | | (_) | |                   " << endl;
		cout << "   | |      ___   __  __  | |_    | |__      __| |  _  | |_   ___    _ __   " << endl;
		cout << "   | |     / _ \\  \\ \\/ /  | __|   |  __|    / _` | | | | __| / _ \\  | '__|  " << endl;
		cout << "   | |    |  __/   >  <   | |_    | |____  | (_| | | | | |_ | (_) | | |     " << endl;
		cout << "   |_|    \\___|   /_/\\_\\  \\__|    |______|  \\__,_| |_| \\__|  \\___/  |_|     " << endl;

		cout << "-------------------------------------------------------------------------------" << char(191) << endl;
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
		cout << "Menu";
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
		cout << ":                                                                          |" << endl;
		cout << "-------------------------------------------------------------------------------|" << endl;
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
		cout << "F2";
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
		cout << "- Save File";
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
		cout << "	F3";
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
		cout << " -Read From File   ";
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
		cout << "Esc";
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
		cout << "- Quit                                 | " << endl;
		cout << "                                                                               |" << endl;
		cout << "-------------------------------------------------------------------------------" << char(180) << endl;
		cout << "                                                                               |" << endl;
		cout << "                                                                               |" << endl;
		cout << "                                                                               |" << endl;
		cout << "                                                                               |" << endl;
		cout << "                                                                               |" << endl;
		cout << "                                                                               |" << endl;
		cout << "                                                                               |" << endl;
		cout << "                                                                               |" << endl;
		cout << "                                                                               |" << endl;
		cout << "                                                                               |" << endl;
		cout << "-------------------------------------------------------------------------------" << char(217) << endl;

		gotoxy(0, 12);

		//displays linked list in console
		for (int i = 0; i < 10; i++)
		{
			if (rows[i] != nullptr)
			{
				Node* T;
				T = rows[i];
				while (T != nullptr)
				{
					cout << T->letter;
					T = T->next;
				}
				cout << endl;
			}
		}
		gotoxy(x, y);
	}
	system("cls"); //clears screen after escape is pressed
}