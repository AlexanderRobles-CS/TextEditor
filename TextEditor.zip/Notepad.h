#pragma once
#include <iostream>
#include <string>
#include <conio.h>
#include <windows.h>
#include <fstream>

using namespace std;

void gotoxy(int column, int line);
 
class Node
{
public:
	char letter; //initializes letter
	Node* prev; //initialize prev ptr
	Node* next; //initialize next ptr
	Node() { next = prev = nullptr; };
	Node(char c) { next = prev = nullptr; letter = c; };
	void Run();
};